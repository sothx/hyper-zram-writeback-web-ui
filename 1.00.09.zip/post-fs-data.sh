MODDIR=${0%/*}
. "$MODDIR"/util_functions.sh
api_level_arch_detect