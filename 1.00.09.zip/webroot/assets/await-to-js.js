/**
 * Bundled by jsDelivr using Rollup v2.79.1 and Terser v5.19.2.
 * Original file: /npm/await-to-js@3.0.0/dist/await-to-js.es5.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */
function n(n,t){return n.then((function(n){return[null,n]})).catch((function(n){return t&&Object.assign(n,t),[n,void 0]}))}export{n as default,n as to};
//# sourceMappingURL=/sm/025e0847b660a188ac9b485e898ec8a4f2903168a25f025493f5ed89b5d8a5e1.map